<?xml version="1.0"?><OpenSearchDescription xmlns="http://a9.com/-/spec/opensearch/1.1/" xmlns:moz="http://www.mozilla.org/2006/browser/search/"><!DOCTYPE html>
<html><head><title>Internal error - Earl's Test Wiki</title><style>body { font-family: sans-serif; margin: 0; padding: 0.5em 2em; }</style></head><body>
<div class="errorbox mw-content-ltr">[YcpTTOf95iA8FVC0mY-2UAAAAfY] 2021-12-27 23:59:08: Fatal exception of type &quot;BadMethodCallException&quot;</div>
<!-- Set $wgShowExceptionDetails = true; at the bottom
of LocalSettings.php to show detailed debugging
information. --></body></html>
